﻿
namespace GPA_calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lg1 = new System.Windows.Forms.Label();
            this.lg2 = new System.Windows.Forms.Label();
            this.lg3 = new System.Windows.Forms.Label();
            this.lg4 = new System.Windows.Forms.Label();
            this.lg5 = new System.Windows.Forms.Label();
            this.lg6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.txtu1 = new System.Windows.Forms.TextBox();
            this.txtu2 = new System.Windows.Forms.TextBox();
            this.txtu3 = new System.Windows.Forms.TextBox();
            this.txtu4 = new System.Windows.Forms.TextBox();
            this.txtu5 = new System.Windows.Forms.TextBox();
            this.txtu6 = new System.Windows.Forms.TextBox();
            this.txts1 = new System.Windows.Forms.TextBox();
            this.txts2 = new System.Windows.Forms.TextBox();
            this.txts3 = new System.Windows.Forms.TextBox();
            this.txts4 = new System.Windows.Forms.TextBox();
            this.txts5 = new System.Windows.Forms.TextBox();
            this.txts6 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.logp = new System.Windows.Forms.Label();
            this.lgpa = new System.Windows.Forms.Label();
            this.lcp = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lp6 = new System.Windows.Forms.Label();
            this.lp5 = new System.Windows.Forms.Label();
            this.lp4 = new System.Windows.Forms.Label();
            this.lp3 = new System.Windows.Forms.Label();
            this.lp2 = new System.Windows.Forms.Label();
            this.lp1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Course";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(107, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Credit Unit";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(191, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Scores";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(264, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Grades";
            // 
            // lg1
            // 
            this.lg1.AutoSize = true;
            this.lg1.Location = new System.Drawing.Point(269, 223);
            this.lg1.Name = "lg1";
            this.lg1.Size = new System.Drawing.Size(35, 13);
            this.lg1.TabIndex = 5;
            this.lg1.Text = "label6";
            this.lg1.Visible = false;
            // 
            // lg2
            // 
            this.lg2.AutoSize = true;
            this.lg2.Location = new System.Drawing.Point(270, 259);
            this.lg2.Name = "lg2";
            this.lg2.Size = new System.Drawing.Size(35, 13);
            this.lg2.TabIndex = 6;
            this.lg2.Text = "label7";
            this.lg2.Visible = false;
            // 
            // lg3
            // 
            this.lg3.AutoSize = true;
            this.lg3.Location = new System.Drawing.Point(270, 290);
            this.lg3.Name = "lg3";
            this.lg3.Size = new System.Drawing.Size(35, 13);
            this.lg3.TabIndex = 7;
            this.lg3.Text = "label8";
            this.lg3.Visible = false;
            // 
            // lg4
            // 
            this.lg4.AutoSize = true;
            this.lg4.Location = new System.Drawing.Point(270, 325);
            this.lg4.Name = "lg4";
            this.lg4.Size = new System.Drawing.Size(35, 13);
            this.lg4.TabIndex = 8;
            this.lg4.Text = "label9";
            this.lg4.Visible = false;
            // 
            // lg5
            // 
            this.lg5.AutoSize = true;
            this.lg5.Location = new System.Drawing.Point(270, 356);
            this.lg5.Name = "lg5";
            this.lg5.Size = new System.Drawing.Size(41, 13);
            this.lg5.TabIndex = 9;
            this.lg5.Text = "label10";
            this.lg5.Visible = false;
            // 
            // lg6
            // 
            this.lg6.AutoSize = true;
            this.lg6.Location = new System.Drawing.Point(270, 388);
            this.lg6.Name = "lg6";
            this.lg6.Size = new System.Drawing.Size(41, 13);
            this.lg6.TabIndex = 10;
            this.lg6.Text = "label11";
            this.lg6.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(34, 218);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(43, 20);
            this.textBox1.TabIndex = 21;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(34, 255);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(43, 20);
            this.textBox2.TabIndex = 22;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(34, 287);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(43, 20);
            this.textBox3.TabIndex = 23;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(34, 320);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(43, 20);
            this.textBox4.TabIndex = 26;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(34, 352);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(43, 20);
            this.textBox5.TabIndex = 25;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(33, 384);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(43, 20);
            this.textBox6.TabIndex = 24;
            // 
            // txtu1
            // 
            this.txtu1.Location = new System.Drawing.Point(113, 218);
            this.txtu1.Name = "txtu1";
            this.txtu1.Size = new System.Drawing.Size(43, 20);
            this.txtu1.TabIndex = 30;
            // 
            // txtu2
            // 
            this.txtu2.Location = new System.Drawing.Point(114, 253);
            this.txtu2.Name = "txtu2";
            this.txtu2.Size = new System.Drawing.Size(43, 20);
            this.txtu2.TabIndex = 29;
            // 
            // txtu3
            // 
            this.txtu3.Location = new System.Drawing.Point(114, 286);
            this.txtu3.Name = "txtu3";
            this.txtu3.Size = new System.Drawing.Size(43, 20);
            this.txtu3.TabIndex = 28;
            // 
            // txtu4
            // 
            this.txtu4.Location = new System.Drawing.Point(114, 319);
            this.txtu4.Name = "txtu4";
            this.txtu4.Size = new System.Drawing.Size(43, 20);
            this.txtu4.TabIndex = 27;
            this.txtu4.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // txtu5
            // 
            this.txtu5.Location = new System.Drawing.Point(114, 351);
            this.txtu5.Name = "txtu5";
            this.txtu5.Size = new System.Drawing.Size(43, 20);
            this.txtu5.TabIndex = 44;
            // 
            // txtu6
            // 
            this.txtu6.Location = new System.Drawing.Point(114, 384);
            this.txtu6.Name = "txtu6";
            this.txtu6.Size = new System.Drawing.Size(43, 20);
            this.txtu6.TabIndex = 43;
            // 
            // txts1
            // 
            this.txts1.Location = new System.Drawing.Point(188, 217);
            this.txts1.Name = "txts1";
            this.txts1.Size = new System.Drawing.Size(43, 20);
            this.txts1.TabIndex = 40;
            // 
            // txts2
            // 
            this.txts2.Location = new System.Drawing.Point(188, 253);
            this.txts2.Name = "txts2";
            this.txts2.Size = new System.Drawing.Size(43, 20);
            this.txts2.TabIndex = 39;
            // 
            // txts3
            // 
            this.txts3.Location = new System.Drawing.Point(188, 286);
            this.txts3.Name = "txts3";
            this.txts3.Size = new System.Drawing.Size(43, 20);
            this.txts3.TabIndex = 38;
            // 
            // txts4
            // 
            this.txts4.Location = new System.Drawing.Point(188, 319);
            this.txts4.Name = "txts4";
            this.txts4.Size = new System.Drawing.Size(43, 20);
            this.txts4.TabIndex = 37;
            // 
            // txts5
            // 
            this.txts5.Location = new System.Drawing.Point(188, 351);
            this.txts5.Name = "txts5";
            this.txts5.Size = new System.Drawing.Size(43, 20);
            this.txts5.TabIndex = 36;
            // 
            // txts6
            // 
            this.txts6.Location = new System.Drawing.Point(188, 384);
            this.txts6.Name = "txts6";
            this.txts6.Size = new System.Drawing.Size(43, 20);
            this.txts6.TabIndex = 35;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(38, 581);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(0, 13);
            this.label22.TabIndex = 47;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(33, 474);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(106, 13);
            this.label23.TabIndex = 46;
            this.label23.Text = "Grade Point Average";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(34, 440);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(85, 13);
            this.label24.TabIndex = 45;
            this.label24.Text = "Cumulative point";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(383, 451);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 55);
            this.button1.TabIndex = 48;
            this.button1.Text = "Compute GPA";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(33, 507);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(99, 13);
            this.label25.TabIndex = 49;
            this.label25.Text = "Overall Grade Point";
            // 
            // logp
            // 
            this.logp.AutoSize = true;
            this.logp.Location = new System.Drawing.Point(213, 504);
            this.logp.Name = "logp";
            this.logp.Size = new System.Drawing.Size(41, 13);
            this.logp.TabIndex = 52;
            this.logp.Text = "label26";
            this.logp.Visible = false;
            // 
            // lgpa
            // 
            this.lgpa.AutoSize = true;
            this.lgpa.Location = new System.Drawing.Point(213, 474);
            this.lgpa.Name = "lgpa";
            this.lgpa.Size = new System.Drawing.Size(41, 13);
            this.lgpa.TabIndex = 51;
            this.lgpa.Text = "label27";
            this.lgpa.Visible = false;
            // 
            // lcp
            // 
            this.lcp.AutoSize = true;
            this.lcp.Location = new System.Drawing.Point(213, 441);
            this.lcp.Name = "lcp";
            this.lcp.Size = new System.Drawing.Size(41, 13);
            this.lcp.TabIndex = 50;
            this.lcp.Text = "label28";
            this.lcp.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GPA_calculator.Properties.Resources.riphah_logo;
            this.pictureBox1.Location = new System.Drawing.Point(36, 38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(89, 82);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(289, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(317, 36);
            this.label6.TabIndex = 54;
            this.label6.Text = "GPA  CALCULATOR";
            // 
            // lp6
            // 
            this.lp6.AutoSize = true;
            this.lp6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lp6.Location = new System.Drawing.Point(341, 389);
            this.lp6.Name = "lp6";
            this.lp6.Size = new System.Drawing.Size(41, 13);
            this.lp6.TabIndex = 61;
            this.lp6.Text = "label11";
            this.lp6.Visible = false;
            // 
            // lp5
            // 
            this.lp5.AutoSize = true;
            this.lp5.Location = new System.Drawing.Point(341, 357);
            this.lp5.Name = "lp5";
            this.lp5.Size = new System.Drawing.Size(41, 13);
            this.lp5.TabIndex = 60;
            this.lp5.Text = "label10";
            this.lp5.Visible = false;
            // 
            // lp4
            // 
            this.lp4.AutoSize = true;
            this.lp4.Location = new System.Drawing.Point(341, 326);
            this.lp4.Name = "lp4";
            this.lp4.Size = new System.Drawing.Size(35, 13);
            this.lp4.TabIndex = 59;
            this.lp4.Text = "label9";
            this.lp4.Visible = false;
            // 
            // lp3
            // 
            this.lp3.AutoSize = true;
            this.lp3.Location = new System.Drawing.Point(341, 291);
            this.lp3.Name = "lp3";
            this.lp3.Size = new System.Drawing.Size(35, 13);
            this.lp3.TabIndex = 58;
            this.lp3.Text = "label8";
            this.lp3.Visible = false;
            // 
            // lp2
            // 
            this.lp2.AutoSize = true;
            this.lp2.Location = new System.Drawing.Point(341, 260);
            this.lp2.Name = "lp2";
            this.lp2.Size = new System.Drawing.Size(35, 13);
            this.lp2.TabIndex = 57;
            this.lp2.Text = "label7";
            this.lp2.Visible = false;
            // 
            // lp1
            // 
            this.lp1.AutoSize = true;
            this.lp1.Location = new System.Drawing.Point(340, 224);
            this.lp1.Name = "lp1";
            this.lp1.Size = new System.Drawing.Size(35, 13);
            this.lp1.TabIndex = 56;
            this.lp1.Text = "label6";
            this.lp1.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(341, 189);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 55;
            this.label12.Text = "Point";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 543);
            this.Controls.Add(this.lp6);
            this.Controls.Add(this.lp5);
            this.Controls.Add(this.lp4);
            this.Controls.Add(this.lp3);
            this.Controls.Add(this.lp2);
            this.Controls.Add(this.lp1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.logp);
            this.Controls.Add(this.lgpa);
            this.Controls.Add(this.lcp);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.txtu5);
            this.Controls.Add(this.txtu6);
            this.Controls.Add(this.txts1);
            this.Controls.Add(this.txts2);
            this.Controls.Add(this.txts3);
            this.Controls.Add(this.txts4);
            this.Controls.Add(this.txts5);
            this.Controls.Add(this.txts6);
            this.Controls.Add(this.txtu1);
            this.Controls.Add(this.txtu2);
            this.Controls.Add(this.txtu3);
            this.Controls.Add(this.txtu4);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lg6);
            this.Controls.Add(this.lg5);
            this.Controls.Add(this.lg4);
            this.Controls.Add(this.lg3);
            this.Controls.Add(this.lg2);
            this.Controls.Add(this.lg1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lg1;
        private System.Windows.Forms.Label lg2;
        private System.Windows.Forms.Label lg3;
        private System.Windows.Forms.Label lg4;
        private System.Windows.Forms.Label lg5;
        private System.Windows.Forms.Label lg6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox txtu1;
        private System.Windows.Forms.TextBox txtu2;
        private System.Windows.Forms.TextBox txtu3;
        private System.Windows.Forms.TextBox txtu4;
        private System.Windows.Forms.TextBox txtu5;
        private System.Windows.Forms.TextBox txtu6;
        private System.Windows.Forms.TextBox txts1;
        private System.Windows.Forms.TextBox txts2;
        private System.Windows.Forms.TextBox txts3;
        private System.Windows.Forms.TextBox txts4;
        private System.Windows.Forms.TextBox txts5;
        private System.Windows.Forms.TextBox txts6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label logp;
        private System.Windows.Forms.Label lgpa;
        private System.Windows.Forms.Label lcp;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lp6;
        private System.Windows.Forms.Label lp5;
        private System.Windows.Forms.Label lp4;
        private System.Windows.Forms.Label lp3;
        private System.Windows.Forms.Label lp2;
        private System.Windows.Forms.Label lp1;
        private System.Windows.Forms.Label label12;
    }
}

